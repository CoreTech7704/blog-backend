const router = require("express").Router();
const admin = require("../controllers/admin.controller");
const adminAuth = require("../middlewares/admin-auth.middleware");

/* Auth */
router.get("/login", admin.loginPage);
router.post("/login", admin.login);

/* Protected */
router.get("/dashboard", adminAuth, admin.dashboard);

router.get("/blogs", adminAuth, admin.blogs);
router.post("/blogs/:id/publish", adminAuth, admin.publishBlog);
router.post("/blogs/:id/unpublish", adminAuth, admin.unpublishBlog);
router.post("/blogs/:id/delete", adminAuth, admin.deleteBlog);

router.get("/categories", adminAuth, admin.categories);
router.post("/categories", adminAuth, admin.createCategory);
router.post("/categories/:id/delete", adminAuth, admin.deleteCategory);

router.get("/users", adminAuth, admin.users);

module.exports = router;
